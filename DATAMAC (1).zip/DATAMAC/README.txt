DATA201 Group Assignment
Group Name: DATAMAC

Jupyter Notebooks:
We have four Jupyter Notebooks. There are three for each dataset we cleaned and produced - 'Earthquake', 'MentalHealth' and 'Population'. Finally, there is a notebook called 'Plotting' in which all of the data is plotted, and the cleaned data from the three notebooks: Earthquake, Mental Health and Population are combined in the Plotting notebook to create plots relative to the research question for our project.

GitHub:
Our github repository is accessible through the link: https://github.com/adaizh/datamac. 
This repository contains all the data files used for the assignment, datasheets for each dataset, and Jupyter Notebooks.

R Package:
Our produced data can be viewed as a .csv file in our submission. However, if it is accessed through our R package then each data set can be viewed individually, and combined as desired. This can be done with the following R code:

install.packages("remotes")
remotes::install_github("chenthih/nzmentalquake") 
